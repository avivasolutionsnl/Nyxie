'use strict';
var yeoman = require('yeoman-generator');
var chalk = require('chalk');
var yosay = require('yosay');

module.exports = yeoman.Base.extend({

  prompting: function () {
    var done = this.async();
    var cmdName = "";

    // Have Yeoman greet the user.
    this.log(yosay(
      'Welcome to the ' + chalk.green('Sitecore Commerce Plugin Command Scaffolding') + ' generator!'
    ));

    // Ask for user input
    var prompts = [
    {
      type: 'input',
      name: 'commandName',
      message: 'What is the command name?',
      default: this.appname
    },
    {
      type: 'input',
      name: 'returnType',
      message: 'What is the return type of the command?',
      default: 'SampleEntity'
    },
    {
      type: 'input',
      name: 'pipelineReceives',
      message: 'What is the receive type of the pipeline?',
      default: function(answers) { return answers.commandName + 'Argument'; }
    },
    {
      type: 'input',
      name: 'pipelineReturns',
      message: 'What is the return type of the pipeline?',
      default: function(answers) { return answers.commandName + 'Argument'; }
    }
  ];

    this.prompt(prompts, function (props) {
      this.props = props;
      // To access props later use this.props.someAnswer;
      this.log(props.commandName);
      this.log("You entered this: " + cmdName);
      done();
    }.bind(this));
    },

    writing: function () {
      this.fs.copyTpl(
        this.templatePath('Commands/SampleCommand.cs'),
        this.destinationPath('Commands/' + this.props.commandName + 'Command.cs'), {
        commandName: this.props.commandName,
        returnType: this.props.returnType,
        pipelineReceives: this.props.pipelineReceives,
        pipelineReturns: this.props.pipelineReturns
      }
      );

    // this.fs.copyTpl(
    //     this.templatePath('Controller/SampleController.cs'),
    //     this.destinationPath('Controller/' + this.props.commandName + 'Controller.cs'), {
    //       commandName: this.props.commandName,
    //       returnType: this.props.returnType,
    //       pipelineReceives: this.props.pipelineReceives,
    //       pipelineReturns: this.props.pipelineReturns
    //   }
    //   );
    //
    // this.fs.copyTpl(
    //     this.templatePath('Controller/CommandsController.cs'),
    //     this.destinationPath('Controller/' + this.props.commandName + 'CommandController.cs'),
    //     {
    //       commandName: this.props.commandName,
    //       returnType: this.props.returnType,
    //       pipelineReceives: this.props.pipelineReceives,
    //       pipelineReturns: this.props.pipelineReturns
    //   }
    //   );

    this.fs.copyTpl(
        this.templatePath('Pipelines/Arguments/SampleArgument.cs'),
        this.destinationPath('Pipelines/Arguments/' + this.props.commandName + 'Argument.cs'), {
          commandName: this.props.commandName,
          returnType: this.props.returnType,
          pipelineReceives: this.props.pipelineReceives,
          pipelineReturns: this.props.pipelineReturns
      }
      );

    this.fs.copyTpl(
        this.templatePath('Pipelines/Blocks/SampleBlock.cs'),
        this.destinationPath('Pipelines/Blocks/' + this.props.commandName + 'Block.cs'), {
          commandName: this.props.commandName,
          returnType: this.props.returnType,
          pipelineReceives: this.props.pipelineReceives,
          pipelineReturns: this.props.pipelineReturns
      }
      );

    this.fs.copyTpl(
        this.templatePath('Pipelines/ISamplePipeline.cs'),
        this.destinationPath('Pipelines/I' + this.props.commandName + 'Pipeline.cs'), {
          commandName: this.props.commandName,
          returnType: this.props.returnType,
          pipelineReceives: this.props.pipelineReceives,
          pipelineReturns: this.props.pipelineReturns
      }
      );

    this.fs.copyTpl(
        this.templatePath('Pipelines/SamplePipeline.cs'),
        this.destinationPath('Pipelines/' + this.props.commandName + 'Pipeline.cs'), {
          commandName: this.props.commandName,
          returnType: this.props.returnType,
          pipelineReceives: this.props.pipelineReceives,
          pipelineReturns: this.props.pipelineReturns
      }
      );
    },

    //install: function () {
    //this.installDependencies();
    //}
});
