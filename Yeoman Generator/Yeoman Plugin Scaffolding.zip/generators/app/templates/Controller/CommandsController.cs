﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="<%= commandName %>CommandsController.cs" company="Sitecore Corporation">
//   Copyright (c) Sitecore Corporation 1999-2016
// </copyright>
// <summary>
//   Defines the <%= commandName %>CommandsController controller.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Sitecore.Commerce.Plugin.Sample
{
    using Microsoft.AspNet.Mvc;
    using Sitecore.Commerce.Core;
    using System;
    using System.Web.Http.OData;

    public class CommandsController : CommerceController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CommandsController"/> class.
        /// </summary>
        /// <param name="serviceProvider">The service provider.</param>
        /// <param name="globalEnvironment">The global environment.</param>
        public CommandsController(IServiceProvider serviceProvider, CommerceEnvironment globalEnvironment) : base(serviceProvider, globalEnvironment)
        { }

        /// <summary>
        /// <%= commandName %> the command.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        [HttpPut]
        [Route("<%= commandName %>()")]
        public IActionResult <%= commandName %>([FromBody] ODataActionParameters value)
        {
            var id = value["Id"].ToString();
            var command = Command<<%= commandName %>Command>();
            var result = command.Process(CurrentContext, id).Result;

            return new ObjectResult(command);
        }
    }
}
