﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="<%= commandName %>Controller.cs" company="Sitecore Corporation">
//   Copyright (c) Sitecore Corporation 1999-2016
// </copyright>
// <summary>
//   Defines the <%= commandName %>Controller controller for the sample plugin.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Sitecore.Commerce.Plugin.Sample
{
    using Microsoft.AspNet.Mvc;
    using Sitecore.Commerce.Core;
    using System;

    [Microsoft.AspNet.OData.EnableQuery]
    [Route("api/Sample")]
    public class <%= commandName %>Controller : CommerceController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="<%= commandName %>Controller"/> class.
        /// </summary>
        /// <param name="serviceProvider">The service provider.</param>
        /// <param name="globalEnvironment">The global environment.</param>
        public <%= commandName %>Controller(IServiceProvider serviceProvider, CommerceEnvironment globalEnvironment) : base(serviceProvider, globalEnvironment)
        {
        }

        /// <summary>
        /// Gets the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        [HttpGet]
        [Route("(Id={id})")]
        [Microsoft.AspNet.OData.EnableQuery]
        public IActionResult Get(string id)
        {
            if (!ModelState.IsValid)
            {
                return new BadRequestObjectResult(ModelState);
            }

            var result = Command<<%= commandName %>Command>()?.Process(CurrentContext, id);
            if (result?.Result == null)
            {
                return HttpNotFound();
            }

            return new ObjectResult(result.Result);
        }
    }
}
