﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="I<%= commandName %>Pipeline.cs" company="Sitecore Corporation">
//   Copyright (c) Sitecore Corporation 1999-2016
// </copyright>
// <summary>
//   I<%= commandName %>Pipeline pipeline interface definition.
// </summary>
// --------------------------------------------------------------------------------------------------------------------


namespace Sitecore.Commerce.Plugin.Sample
{
    using Sitecore.Commerce.Core;
    using Sitecore.Framework.Pipelines;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    /// Defines the I<%= commandName %>Pipeline interface
    /// </summary>
    /// <seealso cref="Sitecore.Framework.Pipelines.IPipeline{Sitecore.Commerce.Plugin.Sample.<%= pipelineReceives %>, Sitecore.Commerce.Plugin.Sample.<%= pipelineReturns %>, Sitecore.Commerce.Core.CommercePipelineExecutionContext}" />
    [PipelineDisplayName("SamplePipeline")]
    public interface I<%= commandName %>Pipeline : IPipeline<<%= pipelineReceives %>, <%= pipelineReturns %>, CommercePipelineExecutionContext>
    {
    }
}
