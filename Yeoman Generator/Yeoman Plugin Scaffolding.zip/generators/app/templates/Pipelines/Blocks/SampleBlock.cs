﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="<%= commandName %>Block.cs" company="Sitecore Corporation">
//   Copyright (c) Sitecore Corporation 1999-2016
// </copyright>
// <summary>
//   <%= commandName %>Block pipeline block.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Sitecore.Commerce.Plugin.Sample
{
    using Sitecore.Framework.Pipelines;
    using System.Threading.Tasks;
    using Sitecore.Commerce.Core;
    using Sitecore.Framework.Conditions;

    public class <%= commandName %>Block : PipelineBlock<<%= pipelineReceives %>, <%= pipelineReturns %>, CommercePipelineExecutionContext>
    {
        private readonly <%= commandName %>Pipeline _pipeline;

        /// <summary>
        /// Initializes a new instance of the <see cref="<%= commandName %>Block"/> class.
        /// </summary>
        /// <param name="pipeline">
        /// The <%= commandName %>Pipeline pipeline.
        /// </param>
        public <%= commandName %>Block(<%= commandName %>Pipeline pipeline)
        {
            this._pipeline = pipeline;
        }

        /// <summary>
        /// The execute.
        /// </summary>
        /// <param name="arg">
        /// The <%= pipelineReceives %> argument.
        /// </param>
        /// <param name="context">
        /// The context.
        /// </param>
        /// <returns>
        /// The <see cref="<%= pipelineReceives %>"/>.
        /// </returns>
        public override Task<<%= pipelineReturns %>> Run(<%= pipelineReceives %> arg, CommercePipelineExecutionContext context)
        {
            Condition.Requires(arg).IsNotNull("The argument can not be null");
            var result = this._pipeline.Run(arg, context).Result;
            return Task.FromResult(result);
        }
    }
}
