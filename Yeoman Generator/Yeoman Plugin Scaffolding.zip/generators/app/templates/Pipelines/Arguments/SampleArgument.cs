﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="<%= commandName %>Argument.cs" company="Sitecore Corporation">
//   Copyright (c) Sitecore Corporation 1999-2016
// </copyright>
// <summary>
//   <%= commandName %>Argument pipeline argument.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Sitecore.Commerce.Plugin.Sample
{
    using Sitecore.Commerce.Core;
    using Sitecore.Framework.Conditions;

    public class <%= commandName %>Argument : PipelineArgument
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="<%= commandName %>Argument"/> class.
        /// </summary>
        /// <param name="parameter">
        /// The parameter.
        /// </param>
        public <%= commandName %>Argument(object parameter)
        {
            Condition.Requires(parameter).IsNotNull("The parameter can not be null");

            this.Parameter = parameter;
        }

        /// <summary>
        /// Gets or sets the parameter.
        /// </summary>
        public object Parameter { get; set; }
    }
}
