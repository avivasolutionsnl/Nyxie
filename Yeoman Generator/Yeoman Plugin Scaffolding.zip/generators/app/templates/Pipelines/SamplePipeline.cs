﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="<%= commandName %>Pipeline.cs" company="Sitecore Corporation">
//   Copyright (c) Sitecore Corporation 1999-2016
// </copyright>
// <summary>
//   <%= commandName %>Pipeline pipeline.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Sitecore.Commerce.Plugin.Sample
{
    using Microsoft.Extensions.Logging;
    using Sitecore.Commerce.Core;
    using Sitecore.Framework.Pipelines;

    /// <summary>
    /// Defines the get <%= commandName %>Pipeline pipeline.
    /// </summary>
    public class <%= commandName %>Pipeline : CommercePipeline<<%= pipelineReceives %>, <%= pipelineReturns %>>, I<%= commandName %>Pipeline
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="<%= commandName %>Pipeline"/> class.
        /// </summary>
        /// <param name="configuration">
        /// The definition.
        /// </param>
        public <%= commandName %>Pipeline(IPipelineConfiguration<<%= commandName %>Pipeline> configuration, ILoggerFactory loggerFactory)
            : base(configuration, loggerFactory)
        {
        }
    }
}
