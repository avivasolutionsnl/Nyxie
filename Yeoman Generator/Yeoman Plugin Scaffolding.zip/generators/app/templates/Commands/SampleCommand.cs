﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="<%= commandName %>Command.cs" company="Sitecore Corporation">
//   Copyright (c) Sitecore Corporation 1999-2016
// </copyright>
// <summary>
//   Defines the <%= commandName %>Command command.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Sitecore.Commerce.Plugin.Sample
{
    using System.Threading.Tasks;
    using Sitecore.Commerce.Core;
    using Core.Commands;

    /// <summary>
    /// Defines the <%= commandName %>Command command.
    /// </summary>
    public class <%= commandName %>Command : CommerceCommand
    {
        private readonly <%= commandName %>Pipeline _pipeline;

        /// <summary>
        /// Initializes a new instance of the <see cref="<%= commandName %>Command"/> class.
        /// </summary>
        /// <param name="pipeline">
        /// The pipeline.
        /// </param>
        public <%= commandName %>Command(<%= commandName %>Pipeline pipeline)
        {
            this._pipeline = pipeline;
        }

        /// <summary>
        /// The process of the command
        /// </summary>
        /// <param name="commerceContext">
        /// The commerce context
        /// </param>
        /// <param name="parameter">
        /// The parameter for the command
        /// </param>
        /// <returns>
        /// The <see cref="Task"/>.
        /// </returns>
        public Task<<%= returnType %>> Process(CommerceContext commerceContext, object parameter)
        {
            using (var activity = CommandActivity.Start(commerceContext, this))
            {
                var arg = new <%= pipelineReceives %>(parameter);
                var result = this._pipeline.Run(arg, new CommercePipelineExecutionContextOptions(commerceContext));

                return Task.FromResult(result.Result);
            }
        }
    }
}
